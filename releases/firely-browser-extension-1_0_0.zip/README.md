# Firely browser extension for FHIR

## Installing locally

1. Go to [chrome://extensions](chrome://extensions) and turn on `Developer Mode` on top-right.
2. Click `Load unpacked` and select the folder where the browser plugin is located

## Testing

To run the JavaScript tests, just open /test/test.html in a browser.